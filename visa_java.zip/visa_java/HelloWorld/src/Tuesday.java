import java.io.Serializable;

/**
 * 
 */

/**
 * @author jwkidd3
 *
 */
public class Tuesday {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Account acct = new Account(12345, "bubba", "123 Rose Lane");
		Account acct2 = new Account();
		Account acctCast=null;
		if (acct instanceof Account) {
			acctCast = (Account) acct;
		}

		System.out.println(acct instanceof Serializable);
		System.out.println(acct instanceof Account);

		System.out.println(acctCast.getName());
		// System.out.println(acct.getAddress());
	}
}

class Account implements Serializable {
	private String name = "noname";
	private String address;
	private int acctNum;
	private double acctVal;
	private boolean active = true;

	public Account() {
	}

	public Account(String name) {
		this.name = name;
	}

	public Account(int n_acctNum, String n_name) {
		this(n_name);
		acctNum = n_acctNum;
	}

	public Account(int n_acctNum, String n_name, String n_address) {
		this(n_acctNum, n_name);
		address = n_address;

	}

	public void close() {
		String reason = "Cannot Stand Bank!";
		double currActVal = 0;
		System.out.println(reason + " - " + currActVal);

	}

	public boolean isActive() {

		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void deposit(double d) {
		acctVal += d;
	}

	public double withdraw(double d) {
		return acctVal -= d;
	}

	public double getBalance() {
		return acctVal;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getAcctNum() {
		return acctNum;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + acctNum;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((name == null) ? 0 : name.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (acctNum != other.acctNum)
			return false;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Account [name=" + name + ", address=" + address + ", acctNum=" + acctNum + "]";
	}
}
