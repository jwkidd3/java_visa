import java.util.ArrayList;
import java.util.List;

public class Sampler {

	public static void main(String[] args) {
		List<Object> l=new ArrayList<>();
		l.add(99);
		l.add("Bubba");
		
		Object x=l.get(1);
		if(x instanceof Integer)
		{
			Integer z=(Integer)x;
		}
		
		
	}

}
