
public class Challenge {
	/**
	 * javadoc comments
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		int a = 4; // this is eol comment
		String b = "bubba";
		Double c = 42.65;

		/*
		 * Block Comment
		 */
		switch (b) {
		case "bubba":
			System.out.println("Welcome to Arkansas...");
			break;
		default:
			break;
		}
		System.out.println(a + " - " + b + " - " + c);
	}

}
