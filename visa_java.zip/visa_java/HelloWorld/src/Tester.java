
public class Tester {

	public static void main(String[] args) {
		A a = new A();
		a.setName("bubba");

		A ab = new A();
		ab.setName("joe");

		System.out.println(ab.getName());
		System.out.println(a.getName());
		System.out.println(ab.color);
		ab.color = "red";
		System.out.println(a.color);
	}

}

class A {
	public static String color = "green";
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
