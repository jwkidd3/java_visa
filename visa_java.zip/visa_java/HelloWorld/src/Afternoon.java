import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

public class Afternoon {

	public static void main(String[] args) {
		int[] arr;
		arr = new int[10];
		arr[0]=1;
		arr[1]=33;
		
	//	System.out.println(arr.length);
		int[] temp;
		int z=arr.length;
		z+=5;
		temp=new int[z];
		System.arraycopy(arr,0, temp, 0, arr.length);
		
		temp[11]=900;
		
//		for (int i : temp) {
//			System.out.println(i);
//		}
		
		Collection<Integer> al =new ArrayList<>();
		al.add(1);
		al.add(3);
		al.add(1);
	//	System.out.println(al.size());
		
	//	int z=al.get(0);
		
//		for (Object object : al) {
//			System.out.println(object);
//		}
		
		Collection<Integer> s=new HashSet<>();
		s.add(1);
		s.add(3);
		s.add(1);
	//	System.out.println(s.size());
	}


	
}


