
public class PrimitivesTest {

	public static final String COMPANY = "VISA";

	public static void main(String[] args) {
		System.out.println(PrimitivesTest.COMPANY);

		long start = System.nanoTime();
		primateTest(10000000);
		System.out.println("Primative: " + (System.nanoTime() - start));

		start = System.nanoTime();
		objTest(10000000);
		System.out.println("Obj: " + (System.nanoTime() - start));

	}

	public static void primateTest(int n) {
		int[] pArr = new int[n];
		long pSum = 0;
		for (int i = 0; i < n; i++) {
			pArr[i] = i;
			pSum += i;
		}
	}

	public static void objTest(int n) {
		Integer[] objArr = new Integer[n];
		long oSum = 0;
		for (int i = 0; i < n; i++) {
			objArr[i] = i;
			oSum += i;
		}
	}

}
