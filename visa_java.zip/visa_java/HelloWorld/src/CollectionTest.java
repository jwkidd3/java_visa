import java.util.LinkedList;
import java.util.List;

public class CollectionTest {

	public static void main(String[] args) {
		List<Integer> list = new LinkedList<>();
		final int counter = 1000000;
		

		int result = 0;

		long startTime = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			list.add(i);
		}
		long endTime = System.currentTimeMillis();

		System.out.println("Add: " + (endTime - startTime));

		startTime = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			list.get(i);
		}
		endTime = System.currentTimeMillis();

		System.out.println("Get: " + (endTime - startTime));
		
		startTime = System.currentTimeMillis();
		for (int i = 0; i < counter; i++) {
			list.remove(0);
		}
		endTime = System.currentTimeMillis();

		System.out.println("Remove: " + (endTime - startTime));

	}

}
