package com.visa.zoo;

import java.util.logging.Logger;

import com.visa.zoo.animal.Animal;
import com.visa.zoo.animal.Dog;
import com.visa.zoo.animal.Duck;
import com.visa.zoo.animal.Giraffe;
import com.visa.zoo.animal.LandDweller;
import com.visa.zoo.animal.Lion;
import com.visa.zoo.animal.Mammal;

public class Runner {
	static Logger log = Logger.getLogger(Runner.class.toString());

	public static void main(String[] args) {
		// Map<Integer,Animal> animals=new HashMap<>();
		Animal[] an = new Animal[10];
		an[0] = new Dog(1, 4, 120, "Yellow");
		an[1] = new Duck(2, 2, 12, "White");
		an[2] = new Giraffe(3, 4, 16, "Yellow");
		an[3] = new Lion(4, 4, 25, "Yellow");
		zooInventory(an);
	}

	private static void zooInventory(Animal[] animals) {
		for (int i = 0; i < animals.length; i++) {
			if (animals[i] != null) {
				log.info(animals[i].toString());
				animals[i].speak();
				if (animals[i] instanceof Dog)
					((Dog) animals[i]).pet();
				
				if(animals[i] instanceof Mammal)
				{
					Mammal m=(Mammal) animals[i];
					m.liveBirth();
				Mammal.doAnother();
					
				}
				if(animals[i] instanceof LandDweller)
				{
					LandDweller m=(LandDweller) animals[i];
					m.walk();
					
				}
			}
		}
	}
}
