package com.visa.zoo.animal;

public class Dog extends Animal implements Mammal,LandDweller{

	public Dog(int id, int legs,  int height, String color) {
		super(id, legs, height, color);
	}

	@Override
	public void speak() {
		System.out.println("Woof");
	}
	
	public void pet()
	{
		System.out.println("wagging tail...");
	}

//	@Override
//	public void liveBirth() {
//		System.out.println("ouch!");
//		
//	}
	
	public void yo()
	{
		System.out.println("Yo");
		String x=super.color;
	}
	
}
