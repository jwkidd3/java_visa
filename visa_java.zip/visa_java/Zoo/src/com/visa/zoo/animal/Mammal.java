package com.visa.zoo.animal;

public interface Mammal {
	public static final String CONSTANT_ITEM = "Bubba";

	public default void liveBirth() {
		System.out.println("ouch!");

	}

	public static void doAnother() {

	}

}
