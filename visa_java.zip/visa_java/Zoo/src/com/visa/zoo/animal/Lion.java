package com.visa.zoo.animal;

public class Lion extends Animal implements Mammal{

	public Lion(int id, int legs, int height, String color) {
		super(id, legs, height, color);
	}
	
	@Override
	public void speak() {
		System.out.println("Roar..");
	}

}
