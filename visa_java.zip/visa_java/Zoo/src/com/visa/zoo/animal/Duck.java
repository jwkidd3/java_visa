package com.visa.zoo.animal;

public class Duck extends Animal {

	public Duck(int id, int legs, int height, String color) {
		super(id, legs, height, color);
	}
	
	@Override
	public void speak() {
		System.out.println("Quack");
	}

}
