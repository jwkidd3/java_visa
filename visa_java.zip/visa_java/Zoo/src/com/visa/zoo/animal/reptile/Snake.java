package com.visa.zoo.animal.reptile;

import com.visa.zoo.animal.Animal;

public class Snake extends Animal{

	public Snake(int id, int legs, int height, String color) {
		super(id, legs, height, color);
	}

	@Override
	public void speak() {
		System.out.println("hiss");
	}

	

}
