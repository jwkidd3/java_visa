package com.visa.zoo.animal;

public class Bubba {

	public Bubba() {
		
	}

}
