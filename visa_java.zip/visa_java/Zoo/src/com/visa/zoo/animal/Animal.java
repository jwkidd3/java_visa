package com.visa.zoo.animal;

import java.util.logging.Logger;

public abstract class Animal {
	Logger log = Logger.getLogger(Animal.class.getName());

	private int id;
	private int legs;
	private int height;
	String color;

	public Animal(int id, int legs, int height, String color) {
		super();
		this.id = id;
		this.legs = legs;
		this.height = height;
		this.color = color;
	}

	public int getId() {
		return id;
	}

	public abstract void speak();

	public int getLegs() {
		return legs;
	}

	public void setLegs(int legs) {
		this.legs = legs;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animal other = (Animal) obj;
		if (id != other.id)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Animal [id=" + id + ", legs=" + legs + ", type=" + this.getClass().getSimpleName() + ", height="
				+ height + ", color=" + color + "]";
	}

}
