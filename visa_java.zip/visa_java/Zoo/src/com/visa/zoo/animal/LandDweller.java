package com.visa.zoo.animal;

public interface LandDweller {

	public default void walk() {
		System.out.println("Walkabout...");
	}

	
	
	public void yo();

}
