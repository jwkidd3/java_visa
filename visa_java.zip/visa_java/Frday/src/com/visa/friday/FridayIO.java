package com.visa.friday;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FridayIO {

	public static void main(String[] args) {
		FileReader fr = null;
		try {
			fr = new FileReader("file.dat");
			int i = fr.read();
			while (i != -1) {
				char ch = (char) i;
				System.out.print(i);
				System.out.print(ch);
				i = fr.read();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fr.close();
			} catch (IOException e) {
				// WDC
			}
		}
	}

}
