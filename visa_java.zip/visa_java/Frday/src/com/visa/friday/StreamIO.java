package com.visa.friday;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class StreamIO {

	public static void main(String[] args) {

		FileInputStream is = null;

		try {
			is = new FileInputStream("bin/com/visa/friday/Friday.class");
			int i = is.read();

			while (i != -1) {
				byte b = (byte) i;
				System.out.print(b);
				i = is.read();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				is.close();
			} catch (IOException e) {
				// WDC
			}
		}

	}

}
