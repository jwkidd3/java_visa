package com.visa.friday;

@FunctionalInterface
public interface WorkerInterface {

	public void doSomeWork(String x);

}
