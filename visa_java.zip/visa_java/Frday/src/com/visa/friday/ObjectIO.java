package com.visa.friday;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ObjectIO {

	public static void main(String[] args) {
		List<Integer> l = new ArrayList<>();
		l.add(new Integer(22));
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		try {
			oos = new ObjectOutputStream(new FileOutputStream("obj.dat"));
			oos.writeObject(l);

			ois = new ObjectInputStream(new FileInputStream("obj.dat"));
			Object obj = ois.readObject();
			List<Integer> ll = (List<Integer>) obj;
			System.out.println(ll.get(0));
		} catch (Exception e) {
			e.printStackTrace();
		}finally
		{
			try {
				ois.close();
				oos.close();
			} catch (IOException e) {
				//WDC
			}
		}

	}

}
