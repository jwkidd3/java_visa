package com.visa.friday;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class BubbaTest {
	private TheTested tt;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Before class....");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("after class...");
	}

	@Before
	public void setUp() throws Exception {
		System.out.println("Setup...");
		tt = new TheTested();
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("Tear down...");
		tt = null;

	}

	@Test
	public void oneTest() {
		System.out.println("Test1");
		int result = tt.doIt(5);
		assertTrue("They did not equal", result == 100);
	}

	@Test
	public void twoTest() {
		System.out.println("Test2");
		int result = tt.doIt(3);
		assertTrue("They did not equal", result == 60);
	}

}
