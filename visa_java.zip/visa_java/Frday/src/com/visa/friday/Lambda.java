package com.visa.friday;

public class Lambda {
	public static void execute(WorkerInterface worker) {
		worker.doSomeWork("Bubba");
	}

	public static void main(String[] args) {

		execute(new WorkerInterface() {
			@Override
			public void doSomeWork(String x) {
				System.out.println("Worker from Anon: " + x);
			}
		}
		);
		
		WorkerInterface wi=(x) -> 
		{
			System.out.println("Lambda: " +x);
		};
		wi.doSomeWork("Bubba");
		
		WorkerInterface wi2=(x) -> 
		{
			System.out.println("Have a great Life: " +x);
		};
		wi2.doSomeWork("Bubba's Wife");
	}
}
