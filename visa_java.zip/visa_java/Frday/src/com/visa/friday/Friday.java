package com.visa.friday;

public class Friday {

	public static void main(String[] args) {

		String name="Bubba";
		String book1="Bubba's life";
		String book2="Bubbas other life";
		
		listBooks(name, book1,book2);
	}
	
	static void listBooks(String name, String... args)
	{
		for (String item : args) {
			System.out.println(item);
		}
		
	}
}
