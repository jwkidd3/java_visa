package com.visa.friday;

public class TheTested {

	public int doIt(int x) {
		return x * 20;
	}

}
