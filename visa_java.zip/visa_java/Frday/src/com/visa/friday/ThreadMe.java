package com.visa.friday;

import java.util.ArrayList;
import java.util.List;

public class ThreadMe {
	public static class MyThread extends Thread {
		public MyThread(String name) {
			super(name);
		}

		public void run() {
			while (true) {
				System.out.println(this.getName());
			}
		}
	}

	public static void main(String[] args) {
		List l=new ArrayList();
		// MyThread m1 = new MyThread("bubba-thread1");
		// m1.start();
		// MyThread m2 = new MyThread("bubba-thread2");
		// m2.start();
		Thread m2 = new Thread(new MyThreadDeux());
		m2.setName("bubba");
		m2.start();
		
		synchronized (l) {
			l.add(new String("bubba"));
		}

	}
}

class MyThreadDeux implements Runnable {

	@Override
	public void run() {
		try {
			String name = Thread.currentThread().getName();
			System.out.println(name);
			Thread.sleep(5000);
			System.out.println("I'm awake again");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}