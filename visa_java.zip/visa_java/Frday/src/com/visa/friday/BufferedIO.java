package com.visa.friday;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class BufferedIO {

	public static void main(String[] args) {
		BufferedReader br = null;
	
		try {
			
			br = new BufferedReader(new FileReader("file.dat"));
			String line = br.readLine();
			while (line != null) {
				System.out.println(line);
				line = br.readLine();
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (IOException e) {
			}
		}

	}

}
