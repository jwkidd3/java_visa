package com.kiddcorp;

public class Statics {
	
	public static void doIt()
	{
		
	}

}
