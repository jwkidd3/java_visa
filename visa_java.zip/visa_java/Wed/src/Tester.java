import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import  com.kiddcorp.Statics;

public class Tester {
	static Logger l = Logger.getLogger("Tester");
	Date d;

	public static void main(String[] args) {
		try {
			Statics.doIt();
			
			doIt1();
		} catch (VisaException e) {
			l.log(Level.WARNING, "", e);
			return;
		}
		System.out.println("yo Bubba!");
	}

	private static void doIt1() throws VisaException, NumberFormatException {
		try {
			doIt2();
		} finally {
			l.log(Level.INFO,"Told you it was finally!");
		}
		
	}

	private static void doIt2() throws VisaException {
		int[] arr = { 1, 2, 3, 4 };
		try {
			int y = arr[5];
			Integer.parseInt("abc");

		} catch (Exception e) {
			throw new VisaException("Bumer", e);
		} 
		System.out.println("Yo");

	}

}
