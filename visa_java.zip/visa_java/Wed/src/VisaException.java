
public class VisaException extends Exception {

	public VisaException() {
		super();
	}

	public VisaException(String message, Throwable cause) {
		
		super(message, cause);
	}

	public VisaException(String message) {
		super(message);
	}

	
}
