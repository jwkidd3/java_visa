package com.visa.home;

public class Afternoon {
   public static final String CONST_VAL="bubba";
	public static void main(String[] args) {
		Media m;
		
		m=Media.BOOK;
		System.out.println(m.getPrice());
		
		for (Media mm : m.values()) {
			System.out.println(mm);
			
		}

	}

}
