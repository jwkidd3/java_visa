package com.visa.home;

public class GenericRunner {

	public static void main(String[] args) {
		MyGenericClass<String, StringBuffer> x = new MyGenericClass<>();
		x.myGenericMethod("Bubba", new StringBuffer());

	}
}

class MyGenericClass<T extends CharSequence, V extends CharSequence> {
	public void myGenericMethod(T parm1, V parm2) {

	}
}
