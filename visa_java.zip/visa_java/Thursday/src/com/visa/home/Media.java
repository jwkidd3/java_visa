package com.visa.home;

public enum Media {
	CD (10.0),DVD (15.0),BOOK(1.0),VHS(1.5);
	
	private final double price;
	Media(double p)
	{
		price=p;
	}
	public double getPrice()
	{
		return price;
	}

}
