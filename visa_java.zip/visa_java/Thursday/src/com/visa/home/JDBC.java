package com.visa.home;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

public class JDBC {
	private static final String DB_URL = "jdbc:derby://localhost:1527/theDb;create=true;user=bubba;password=bubba";
	private static final String TABLE = "eatery";
	private static final String DRIVER_NAME = "org.apache.derby.jdbc.ClientDriver";
	private static Connection conn;
	private static PreparedStatement ps;

	public static void main(String[] args) {
		try {
			Class.forName(DRIVER_NAME);
			conn = DriverManager.getConnection(DB_URL);

			/* Insert a record */
			ps = conn.prepareStatement("INSERT INTO " + TABLE + " values(?,?,?)");
			ps.setInt(1, 6);
			ps.setString(2, "Hubba Bubba");
			ps.setString(3, "San Jose");
			int recs = ps.executeUpdate();
			System.out.println("Records Inserted: " + recs);

			ps = conn.prepareStatement("SELECT * FROM " + TABLE);
			ResultSet rs = ps.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int cols = rsmd.getColumnCount();
			for (int i = 1; i <= cols; i++) {
				
				System.out.print(rsmd.getColumnLabel(i) + "\t\t");
			}
			System.out.println("\n---------------------------------------");
			while (rs.next()) {
				int id = rs.getInt(1);
				String restName = rs.getString(2);
				String city = rs.getString(3);
				System.out.println(id + "\t\t" + restName + "\t\t" + city);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				ps.close();
				conn.close();
			} catch (Exception e) {
				// WDC
			}

		}

	}

}
