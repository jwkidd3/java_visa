package com.visa.home;

import java.lang.reflect.Method;

public class Annotate {

	public static void main(String[] args) {
		try {
			Class<?> clazz = Class.forName("com.visa.home.TestAnnotations");
			Method[] methods = clazz.getDeclaredMethods();
			Method m3 = null;

			for (Method method : methods) {
				System.out.println("Processing Method: " + method.getName() + " -> " + method.getReturnType());

				if (method.isAnnotationPresent(MyAnnotation.class)) {
					MyAnnotation ma = method.getAnnotation(MyAnnotation.class);
					System.out.println(ma.p1());
					if (method.getName().equals("m3")) {
						m3 = method;
						Object obj = clazz.newInstance();
						Object[] argx = null;
						m3.invoke(obj, argx);
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
class TestAnnotations {
	private String name = "bubba";

	//@MyAnnotation(p1 = "Yo", p2 = "yoyo")
	public void m1() {

	}

	//@MyAnnotation(p1 = "Yo", p2 = "yoyo", p3 = "Bubba's Cousin")
	public void m2() {

	}
	
	@MyAnnotation(p1 = "Yo", p2 = "yoyo")
	public void m3() {
		System.out.println("Bubba's Wife");
	}
}

