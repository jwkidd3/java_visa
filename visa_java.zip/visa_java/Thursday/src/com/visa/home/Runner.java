package com.visa.home;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Runner {

	public static void main(String[] args) {
		List<? extends Number> l = new ArrayList<>();
		// l.add(new Integer(123123));

		Set<Student> ss = new TreeSet<>();
		ss.add(new Student(45, 3.5, "Joe"));
		ss.add(new Student(13, 1.9, "Bubba"));
		ss.add(new Student(5, 3.75, "Sally"));
		ss.add(new Student(7, 3.9, "Harry"));

		for (Student student : ss) {
			System.out.println(student.getStudentID() + " - " + student.getName());
		}

	}
}

class Student implements Comparable<Student> {
	private int studentID;
	private double gpa;
	private String name;

	public Student(int studentID, double gpa, String name) {
		super();
		this.studentID = studentID;
		this.gpa = gpa;
		this.name = name;
	}

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public double getGpa() {
		return gpa;
	}

	public void setGpa(double gpa) {
		this.gpa = gpa;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + studentID;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Student other = (Student) obj;
		if (studentID != other.studentID)
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Student [studentID=" + studentID + ", gpa=" + gpa + ", name=" + name + "]";
	}

	@Override
	public int compareTo(Student s) {
		System.out.println("Compare too....");
		return this.studentID - s.studentID;
	}

}