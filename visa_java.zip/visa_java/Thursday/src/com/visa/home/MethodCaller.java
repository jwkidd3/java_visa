package com.visa.home;

public class MethodCaller {

	public static void main(String[] args) {
		StringBuilder mysb = new StringBuilder("abc");
		m1(mysb);
		System.out.println(mysb);
		
		Holder g=new Holder();
		g.v=12;
		m2(g);
		System.out.println(g.v);
	}

	static void m1(StringBuilder sb) {
		sb.append(" bubba");
	}
	
	static void m2(Holder x) {
		x.v=55;
	}
}
class Holder
{
	public int v=0;
}
