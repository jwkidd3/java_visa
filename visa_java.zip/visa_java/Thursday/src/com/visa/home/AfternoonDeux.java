package com.visa.home;

public class AfternoonDeux {

	public static void main(String[] args) {
		StudentDeux s = new StudentDeux(5, "Bubba");
		try {
			StudentDeux q = (StudentDeux) s.clone();

			System.out.println("S: " + s.getId() + " - " + s.getName());
			System.out.println("Q: " + q.getId() + " - " + q.getName());

			s.name.append(" wife");
			System.out.println("Q: " + q.getId() + " - " + q.getName());
			// System.out.println(s.getName() == q.getName());
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}
}

class StudentDeux implements Cloneable {
	private int id;
	public StringBuilder name;

	public StudentDeux(int id, String name) {
		super();
		this.id = id;
		this.name = new StringBuilder(name);
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name.toString();
	}

	public void setName(String name) {
		this.name = new StringBuilder(name);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StudentDeux other = (StudentDeux) obj;
		if (id != other.id)
			return false;
		return true;
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
}
