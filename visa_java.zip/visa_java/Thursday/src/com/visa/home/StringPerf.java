package com.visa.home;

public class StringPerf {

	public static void main(String[] args) {
		long start, end;

		String str = new String("");
		StringBuffer sb = new StringBuffer(1000);
		StringBuilder sbb = new StringBuilder(1000);

		start = System.nanoTime();
		for (int i = 0; i < 50000; i++) {
			str += i;
		}
		end = System.nanoTime();
		System.out.println("String Concat: " + (end - start));

		start = System.nanoTime();
		for (int i = 0; i < 50000; i++) {
			sb.append(i);
		}
		end = System.nanoTime();
		System.out.println("StringBuffer: " + (end - start));

		start = System.nanoTime();
		for (int i = 0; i < 50000; i++) {
			sbb.append(i);
		}
		end = System.nanoTime();
		System.out.println("StringBuilder: " + (end - start));

	}

}
